
let showSpinner = function(){
    try{
      document.getElementById("spinner-wrapper").style.display = "block";
    }catch{
  
    }
    
  }
  
  let hideSpinner = function(){
    try{
      document.getElementById("spinner-wrapper").style.display = "none";
    }catch{
  
    }
  }
  